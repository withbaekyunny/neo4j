"""
初始化化妆品成分筛选系统数据
"""
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from src.models.cosmetic import Base, EffectCategory, Ingredient, Product, SkinType, IngredientInteraction
from src.models.cosmetic import effect_ingredient_association, ingredient_product_association, product_skintype_association

# 创建数据库连接
DATABASE_URL = "sqlite:///src/database/app.db"
engine = create_engine(DATABASE_URL)
Base.metadata.create_all(engine)

Session = sessionmaker(bind=engine)
session = Session()

def init_effect_categories():
    """初始化功效类别"""
    effects = [
        {
            "name": "美白淡斑",
            "description": "抑制黑色素生成，淡化色斑，提亮肤色",
            "icon": "brightness"
        },
        {
            "name": "抗衰老",
            "description": "减少皱纹，提升肌肤弹性，延缓衰老",
            "icon": "anti-aging"
        },
        {
            "name": "保湿补水",
            "description": "增强肌肤保湿能力，维持水油平衡",
            "icon": "droplet"
        },
        {
            "name": "控油祛痘",
            "description": "调节油脂分泌，抗炎祛痘，改善肌肤状态",
            "icon": "shield"
        },
        {
            "name": "舒缓修护",
            "description": "舒缓敏感肌肤，修护肌肤屏障",
            "icon": "heart"
        },
        {
            "name": "去角质",
            "description": "温和去除老化角质，促进肌肤更新",
            "icon": "refresh"
        }
    ]
    
    for effect_data in effects:
        effect = EffectCategory(**effect_data)
        session.add(effect)
    
    session.commit()
    print("功效类别初始化完成")

def init_ingredients():
    """初始化成分数据"""
    # 美白淡斑成分 - 化学合成成分
    whitening_chemical = [
        {"name": "氢醌", "english_name": "Hydroquinone", "inci_name": "Hydroquinone", "category": "化学合成", "efficacy_score": 9.5, "evidence_level": "A", "mechanism": "直接抑制酪氨酸酶活性，阻断黑色素生成", "effective_concentration": "2%-4%", "safety_level": "处方药", "side_effects": "可能引起皮肤刺激，长期使用需医生指导"},
        {"name": "苯乙基间苯二酚", "english_name": "Phenylethyl Resorcinol", "inci_name": "Phenylethyl Resorcinol", "category": "化学合成", "efficacy_score": 8.8, "evidence_level": "A", "mechanism": "强效抑制酪氨酸酶，比氢醌温和", "effective_concentration": "0.1%-1%", "safety_level": "较安全", "side_effects": "极少数人可能出现轻微刺激"},
        {"name": "氨甲环酸", "english_name": "Tranexamic Acid", "inci_name": "Tranexamic Acid", "category": "化学合成", "efficacy_score": 8.5, "evidence_level": "A", "mechanism": "抑制纤溶酶原激活，减少黑色素生成", "effective_concentration": "2%-5%", "safety_level": "安全", "side_effects": "极少副作用"},
        {"name": "烟酰胺", "english_name": "Niacinamide", "inci_name": "Niacinamide", "category": "化学合成", "efficacy_score": 8.5, "evidence_level": "A", "mechanism": "阻断黑色素向角质细胞转移", "effective_concentration": "2%-10%", "safety_level": "非常安全", "side_effects": "极少副作用，耐受性好"},
        {"name": "维生素C", "english_name": "L-Ascorbic Acid", "inci_name": "Ascorbic Acid", "category": "化学合成", "efficacy_score": 9.2, "evidence_level": "A", "mechanism": "抑制酪氨酸酶活性，阻断黑色素生成，促进胶原蛋白合成", "effective_concentration": "5%-20%", "safety_level": "安全", "side_effects": "高浓度可能刺激敏感肌肤"},
        {"name": "3-邻-乙基抗坏血酸", "english_name": "3-O-Ethyl Ascorbic Acid", "inci_name": "3-O-Ethyl Ascorbic Acid", "category": "化学合成", "efficacy_score": 8.0, "evidence_level": "A", "mechanism": "稳定的维生素C衍生物，渗透性好", "effective_concentration": "1%-5%", "safety_level": "安全", "side_effects": "刺激性较低"},
        {"name": "曲酸", "english_name": "Kojic Acid", "inci_name": "Kojic Acid", "category": "天然发酵", "efficacy_score": 8.0, "evidence_level": "A", "mechanism": "螯合铜离子，抑制酪氨酸酶活性", "effective_concentration": "1%-4%", "safety_level": "中等", "side_effects": "可能引起接触性皮炎"},
        {"name": "α-熊果苷", "english_name": "Alpha-Arbutin", "inci_name": "Alpha-Arbutin", "category": "化学合成", "efficacy_score": 8.5, "evidence_level": "A", "mechanism": "比β-熊果苷活性更强", "effective_concentration": "0.5%-2%", "safety_level": "安全", "side_effects": "刺激性极低"},
        {"name": "壬二酸", "english_name": "Azelaic Acid", "inci_name": "Azelaic Acid", "category": "天然酸类", "efficacy_score": 8.2, "evidence_level": "A", "mechanism": "抑制酪氨酸酶，具有抗炎作用", "effective_concentration": "10%-20%", "safety_level": "安全", "side_effects": "初期可能有轻微刺激"},
        {"name": "视黄醇", "english_name": "Retinol", "inci_name": "Retinol", "category": "维生素A类", "efficacy_score": 9.0, "evidence_level": "A", "mechanism": "促进细胞更新，加速黑色素代谢", "effective_concentration": "0.25%-1%", "safety_level": "需谨慎", "side_effects": "可能引起刺激，需建立耐受"}
    ]
    
    # 美白淡斑成分 - 植物提取物
    whitening_plant = [
        {"name": "光甘草定", "english_name": "Glabridin", "inci_name": "Glabridin", "category": "植物提取", "efficacy_score": 8.5, "evidence_level": "A", "mechanism": "抑制酪氨酸酶，抗炎", "effective_concentration": "0.1%-2%", "safety_level": "安全", "side_effects": "刺激性很低"},
        {"name": "根皮素", "english_name": "Phloretin", "inci_name": "Phloretin", "category": "植物提取", "efficacy_score": 8.0, "evidence_level": "A", "mechanism": "强抗氧化，抑制酪氨酸酶", "effective_concentration": "0.1%-1%", "safety_level": "安全", "side_effects": "刺激性很低"},
        {"name": "桑树根提取物", "english_name": "Mulberry Root Extract", "inci_name": "Morus Alba Root Extract", "category": "植物提取", "efficacy_score": 7.8, "evidence_level": "A", "mechanism": "抑制酪氨酸酶，美白", "effective_concentration": "1%-5%", "safety_level": "安全", "side_effects": "刺激性很低"},
        {"name": "甘草提取物", "english_name": "Licorice Extract", "inci_name": "Glycyrrhiza Glabra Root Extract", "category": "植物提取", "efficacy_score": 8.2, "evidence_level": "A", "mechanism": "抗炎，舒缓，美白", "effective_concentration": "1%-5%", "safety_level": "安全", "side_effects": "刺激性很低"},
        {"name": "茶叶提取物", "english_name": "Tea Extract", "inci_name": "Camellia Sinensis Leaf Extract", "category": "植物提取", "efficacy_score": 7.8, "evidence_level": "A", "mechanism": "富含茶多酚，强抗氧化", "effective_concentration": "1%-5%", "safety_level": "安全", "side_effects": "刺激性很低"},
        {"name": "阿魏酸", "english_name": "Ferulic Acid", "inci_name": "Ferulic Acid", "category": "植物提取", "efficacy_score": 8.2, "evidence_level": "A", "mechanism": "强抗氧化，稳定维生素C", "effective_concentration": "0.1%-1%", "safety_level": "安全", "side_effects": "刺激性很低"}
    ]
    
    # 抗衰老成分
    antiaging_ingredients = [
        {"name": "视黄醛", "english_name": "Retinal", "inci_name": "Retinal", "category": "维生素A类", "efficacy_score": 9.2, "evidence_level": "A", "mechanism": "比视黄醇温和，抗衰效果显著", "effective_concentration": "0.05%-0.1%", "safety_level": "较安全", "side_effects": "比视黄醇刺激性低"},
        {"name": "补骨脂酚", "english_name": "Bakuchiol", "inci_name": "Bakuchiol", "category": "植物提取", "efficacy_score": 8.0, "evidence_level": "A", "mechanism": "天然视黄醇替代品，孕妇可用", "effective_concentration": "0.5%-2%", "safety_level": "非常安全", "side_effects": "无明显副作用"},
        {"name": "棕榈酰五肽-4", "english_name": "Palmitoyl Pentapeptide-4", "inci_name": "Palmitoyl Pentapeptide-4", "category": "多肽", "efficacy_score": 8.8, "evidence_level": "A", "mechanism": "刺激胶原蛋白、弹性蛋白和透明质酸合成", "effective_concentration": "0.001%-0.01%", "safety_level": "安全", "side_effects": "无明显副作用"},
        {"name": "乙酰基六肽-8", "english_name": "Acetyl Hexapeptide-8", "inci_name": "Acetyl Hexapeptide-8", "category": "多肽", "efficacy_score": 8.5, "evidence_level": "A", "mechanism": "抑制肌肉收缩，减少表情纹", "effective_concentration": "0.001%-0.01%", "safety_level": "安全", "side_effects": "无明显副作用"},
        {"name": "艾地苯", "english_name": "Idebenone", "inci_name": "Idebenone", "category": "化学合成", "efficacy_score": 9.0, "evidence_level": "A", "mechanism": "超强抗氧化，比维生素C强4倍", "effective_concentration": "0.5%-1%", "safety_level": "安全", "side_effects": "刺激性很低"},
        {"name": "虾青素", "english_name": "Astaxanthin", "inci_name": "Astaxanthin", "category": "天然色素", "efficacy_score": 9.2, "evidence_level": "A", "mechanism": "超强抗氧化，比维生素E强1000倍", "effective_concentration": "0.01%-0.1%", "safety_level": "安全", "side_effects": "可能轻微染色"},
        {"name": "玻色因", "english_name": "Bosein", "inci_name": "Mannose", "category": "糖类", "efficacy_score": 8.2, "evidence_level": "A", "mechanism": "刺激胶原蛋白合成，抗糖化", "effective_concentration": "1%-3%", "safety_level": "安全", "side_effects": "无明显副作用"}
    ]
    
    # 保湿补水成分
    moisturizing_ingredients = [
        {"name": "透明质酸钠", "english_name": "Sodium Hyaluronate", "inci_name": "Sodium Hyaluronate", "category": "吸湿剂", "efficacy_score": 9.5, "evidence_level": "A", "mechanism": "能结合1000倍自身重量的水分", "effective_concentration": "0.1%-2%", "safety_level": "非常安全", "side_effects": "无副作用"},
        {"name": "甘油", "english_name": "Glycerin", "inci_name": "Glycerin", "category": "吸湿剂", "efficacy_score": 8.5, "evidence_level": "A", "mechanism": "从环境中吸收水分，保持肌肤湿润", "effective_concentration": "3%-15%", "safety_level": "非常安全", "side_effects": "无副作用"},
        {"name": "神经酰胺", "english_name": "Ceramide", "inci_name": "Ceramide", "category": "脂质", "efficacy_score": 9.0, "evidence_level": "A", "mechanism": "修复肌肤屏障，保湿抗衰", "effective_concentration": "0.1%-5%", "safety_level": "非常安全", "side_effects": "无副作用"},
        {"name": "角鲨烷", "english_name": "Squalane", "inci_name": "Squalane", "category": "油脂", "efficacy_score": 8.0, "evidence_level": "A", "mechanism": "模拟皮脂，深层滋养", "effective_concentration": "1%-10%", "safety_level": "非常安全", "side_effects": "无副作用"},
        {"name": "泛醇", "english_name": "Panthenol", "inci_name": "Panthenol", "category": "维生素", "efficacy_score": 7.5, "evidence_level": "A", "mechanism": "保湿，舒缓，促进细胞修复", "effective_concentration": "1%-5%", "safety_level": "非常安全", "side_effects": "无副作用"},
        {"name": "依克多因", "english_name": "Ectoin", "inci_name": "Ectoin", "category": "氨基酸", "efficacy_score": 8.5, "evidence_level": "A", "mechanism": "保护细胞，抗衰老，保湿", "effective_concentration": "0.5%-2%", "safety_level": "非常安全", "side_effects": "无副作用"}
    ]
    
    # 控油祛痘成分
    acne_control_ingredients = [
        {"name": "水杨酸", "english_name": "Salicylic Acid", "inci_name": "Salicylic Acid", "category": "化学合成", "efficacy_score": 7.8, "evidence_level": "A", "mechanism": "脂溶性，深入毛孔剥脱", "effective_concentration": "0.5%-2%", "safety_level": "较安全", "side_effects": "可能引起干燥"},
        {"name": "过氧苯甲酰", "english_name": "Benzoyl Peroxide", "inci_name": "Benzoyl Peroxide", "category": "化学合成", "efficacy_score": 9.0, "evidence_level": "A", "mechanism": "强效杀菌，剥脱角质", "effective_concentration": "2.5%-10%", "safety_level": "需谨慎", "side_effects": "可能引起刺激和干燥"},
        {"name": "茶树精油", "english_name": "Tea Tree Oil", "inci_name": "Melaleuca Alternifolia Leaf Oil", "category": "植物精油", "efficacy_score": 8.0, "evidence_level": "A", "mechanism": "天然抗菌，抗炎", "effective_concentration": "1%-10%", "safety_level": "较安全", "side_effects": "可能引起过敏"},
        {"name": "锌", "english_name": "Zinc", "inci_name": "Zinc PCA", "category": "矿物质", "efficacy_score": 8.0, "evidence_level": "A", "mechanism": "调节皮脂分泌，抗炎抗菌", "effective_concentration": "0.5%-2%", "safety_level": "安全", "side_effects": "无明显副作用"}
    ]
    
    # 舒缓修护成分
    soothing_ingredients = [
        {"name": "红没药醇", "english_name": "Bisabolol", "inci_name": "Bisabolol", "category": "植物提取", "efficacy_score": 8.5, "evidence_level": "A", "mechanism": "强效抗炎，舒缓", "effective_concentration": "0.1%-1%", "safety_level": "非常安全", "side_effects": "无副作用"},
        {"name": "甘草酸二钾", "english_name": "Dipotassium Glycyrrhizate", "inci_name": "Dipotassium Glycyrrhizate", "category": "植物提取", "efficacy_score": 8.5, "evidence_level": "A", "mechanism": "强效抗炎，舒缓刺激", "effective_concentration": "0.1%-2%", "safety_level": "非常安全", "side_effects": "无副作用"},
        {"name": "积雪草苷", "english_name": "Asiaticoside", "inci_name": "Asiaticoside", "category": "植物提取", "efficacy_score": 8.3, "evidence_level": "A", "mechanism": "促进胶原蛋白合成，修复肌肤", "effective_concentration": "0.1%-1%", "safety_level": "安全", "side_effects": "刺激性很低"},
        {"name": "尿囊素", "english_name": "Allantoin", "inci_name": "Allantoin", "category": "天然成分", "efficacy_score": 8.0, "evidence_level": "A", "mechanism": "促进细胞再生，舒缓", "effective_concentration": "0.1%-2%", "safety_level": "非常安全", "side_effects": "无副作用"}
    ]
    
    # 去角质成分
    exfoliating_ingredients = [
        {"name": "羟基乙酸", "english_name": "Glycolic Acid", "inci_name": "Glycolic Acid", "category": "化学合成", "efficacy_score": 7.5, "evidence_level": "A", "mechanism": "剥脱角质，促进黑色素代谢", "effective_concentration": "5%-30%", "safety_level": "需谨慎", "side_effects": "可能引起刺激和光敏"},
        {"name": "乳酸", "english_name": "Lactic Acid", "inci_name": "Lactic Acid", "category": "化学合成", "efficacy_score": 7.2, "evidence_level": "A", "mechanism": "温和剥脱，促进细胞更新", "effective_concentration": "5%-20%", "safety_level": "较安全", "side_effects": "比甘醇酸温和"},
        {"name": "杏仁酸", "english_name": "Mandelic Acid", "inci_name": "Mandelic Acid", "category": "化学合成", "efficacy_score": 7.0, "evidence_level": "B", "mechanism": "温和剥脱，适合敏感肌", "effective_concentration": "5%-25%", "safety_level": "安全", "side_effects": "刺激性最低的果酸"},
        {"name": "木瓜蛋白酶", "english_name": "Papain", "inci_name": "Papain", "category": "酶类", "efficacy_score": 7.2, "evidence_level": "A", "mechanism": "温和分解死皮细胞", "effective_concentration": "0.1%-1%", "safety_level": "安全", "side_effects": "可能引起过敏"}
    ]
    
    # 合并所有成分
    all_ingredients = (whitening_chemical + whitening_plant + antiaging_ingredients + 
                      moisturizing_ingredients + acne_control_ingredients + 
                      soothing_ingredients + exfoliating_ingredients)
    
    for ingredient_data in all_ingredients:
        ingredient = Ingredient(**ingredient_data)
        session.add(ingredient)
    
    session.commit()
    print(f"成分初始化完成，共添加 {len(all_ingredients)} 个成分")

def init_skin_types():
    """初始化肤质类型"""
    skin_types = [
        {
            "name": "干性肌肤",
            "description": "皮脂分泌较少，容易干燥紧绷",
            "characteristics": "缺水缺油，易起皮，毛孔细小，容易产生细纹",
            "care_tips": "重点补水保湿，选择滋润型产品，避免过度清洁"
        },
        {
            "name": "油性肌肤",
            "description": "皮脂分泌旺盛，容易出油",
            "characteristics": "T区油腻，毛孔粗大，易长痘痘和黑头",
            "care_tips": "控油清洁，选择清爽型产品，注意深层清洁"
        },
        {
            "name": "混合性肌肤",
            "description": "T区偏油，两颊偏干",
            "characteristics": "T区毛孔粗大易出油，两颊干燥紧绷",
            "care_tips": "分区护理，T区控油，两颊保湿"
        },
        {
            "name": "敏感性肌肤",
            "description": "容易受外界刺激产生不适反应",
            "characteristics": "易红肿、刺痛、瘙痒，角质层薄，血管明显",
            "care_tips": "选择温和无刺激产品，避免频繁更换护肤品"
        },
        {
            "name": "中性肌肤",
            "description": "水油平衡，肌肤状态稳定",
            "characteristics": "毛孔细致，肤质光滑，很少出现肌肤问题",
            "care_tips": "维持现状，基础护理即可，注意防晒"
        }
    ]
    
    for skin_type_data in skin_types:
        skin_type = SkinType(**skin_type_data)
        session.add(skin_type)
    
    session.commit()
    print("肤质类型初始化完成")

def init_effect_ingredient_relationships():
    """初始化功效-成分关联关系"""
    # 获取所有功效和成分
    effects = session.query(EffectCategory).all()
    ingredients = session.query(Ingredient).all()
    
    # 创建功效名称到ID的映射
    effect_map = {effect.name: effect.id for effect in effects}
    
    # 创建成分名称到ID的映射
    ingredient_map = {ingredient.name: ingredient.id for ingredient in ingredients}
    
    # 定义功效-成分关联关系
    relationships = [
        # 美白淡斑相关成分
        ("美白淡斑", ["氢醌", "苯乙基间苯二酚", "氨甲环酸", "烟酰胺", "维生素C", 
                  "3-邻-乙基抗坏血酸", "曲酸", "α-熊果苷", "壬二酸", "视黄醇",
                  "光甘草定", "根皮素", "桑树根提取物", "甘草提取物", "茶叶提取物", "阿魏酸"]),
        
        # 抗衰老相关成分
        ("抗衰老", ["视黄醇", "视黄醛", "补骨脂酚", "棕榈酰五肽-4", "乙酰基六肽-8",
                  "维生素C", "艾地苯", "虾青素", "玻色因", "神经酰胺", "角鲨烷",
                  "积雪草苷", "依克多因", "阿魏酸", "茶叶提取物"]),
        
        # 保湿补水相关成分
        ("保湿补水", ["透明质酸钠", "甘油", "神经酰胺", "角鲨烷", "泛醇", "依克多因"]),
        
        # 控油祛痘相关成分
        ("控油祛痘", ["水杨酸", "过氧苯甲酰", "茶树精油", "锌", "烟酰胺", "壬二酸"]),
        
        # 舒缓修护相关成分
        ("舒缓修护", ["红没药醇", "甘草酸二钾", "积雪草苷", "尿囊素", "甘草提取物",
                   "神经酰胺", "角鲨烷", "泛醇", "依克多因"]),
        
        # 去角质相关成分
        ("去角质", ["羟基乙酸", "乳酸", "杏仁酸", "水杨酸", "木瓜蛋白酶", "视黄醇"])
    ]
    
    # 建立关联关系
    for effect_name, ingredient_names in relationships:
        if effect_name in effect_map:
            effect_id = effect_map[effect_name]
            for ingredient_name in ingredient_names:
                if ingredient_name in ingredient_map:
                    ingredient_id = ingredient_map[ingredient_name]
                    # 检查关联是否已存在
                    existing = session.execute(
                        effect_ingredient_association.select().where(
                            (effect_ingredient_association.c.effect_id == effect_id) &
                            (effect_ingredient_association.c.ingredient_id == ingredient_id)
                        )
                    ).first()
                    
                    if not existing:
                        session.execute(
                            effect_ingredient_association.insert().values(
                                effect_id=effect_id,
                                ingredient_id=ingredient_id
                            )
                        )
    
    session.commit()
    print("功效-成分关联关系初始化完成")

if __name__ == "__main__":
    print("开始初始化数据...")
    
    # 清空现有数据
    session.query(IngredientInteraction).delete()
    session.execute(product_skintype_association.delete())
    session.execute(ingredient_product_association.delete())
    session.execute(effect_ingredient_association.delete())
    session.query(Product).delete()
    session.query(SkinType).delete()
    session.query(Ingredient).delete()
    session.query(EffectCategory).delete()
    session.commit()
    
    # 初始化基础数据
    init_effect_categories()
    init_ingredients()
    init_skin_types()
    init_effect_ingredient_relationships()
    
    session.close()
    print("数据初始化完成！")

