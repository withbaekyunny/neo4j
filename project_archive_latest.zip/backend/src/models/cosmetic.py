"""
化妆品成分筛选系统数据模型
"""
from sqlalchemy import Column, Integer, String, Float, Boolean, Text, ForeignKey, Table
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship

Base = declarative_base()

# 多对多关系表：功效-成分
effect_ingredient_association = Table(
    'effect_ingredient',
    Base.metadata,
    Column('effect_id', Integer, ForeignKey('effect_categories.id')),
    Column('ingredient_id', Integer, ForeignKey('ingredients.id'))
)

# 多对多关系表：成分-产品
ingredient_product_association = Table(
    'ingredient_product',
    Base.metadata,
    Column('ingredient_id', Integer, ForeignKey('ingredients.id')),
    Column('product_id', Integer, ForeignKey('products.id')),
    Column('concentration', Float),  # 成分浓度（如果已知）
    Column('position_in_list', Integer),  # 在成分表中的位置
    Column('is_active', Boolean, default=True)  # 是否为活性成分
)

# 多对多关系表：产品-肤质
product_skintype_association = Table(
    'product_skintype',
    Base.metadata,
    Column('product_id', Integer, ForeignKey('products.id')),
    Column('skintype_id', Integer, ForeignKey('skin_types.id'))
)

class EffectCategory(Base):
    """功效类别表"""
    __tablename__ = 'effect_categories'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)  # 功效名称
    description = Column(Text)  # 功效描述
    icon = Column(String(50))  # 图标名称
    
    # 关联关系
    ingredients = relationship(
        "Ingredient",
        secondary=effect_ingredient_association,
        back_populates="effects"
    )

class Ingredient(Base):
    """成分表"""
    __tablename__ = 'ingredients'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(200), nullable=False)  # 成分中文名
    english_name = Column(String(200))  # 成分英文名
    inci_name = Column(String(200))  # INCI名称
    category = Column(String(100))  # 成分类别（化学合成/植物提取等）
    efficacy_score = Column(Float)  # 功效评分（1-10分）
    evidence_level = Column(String(10))  # 证据等级（A/B/C）
    mechanism = Column(Text)  # 作用机理
    effective_concentration = Column(String(100))  # 有效浓度范围
    safety_level = Column(String(20))  # 安全等级
    side_effects = Column(Text)  # 可能的副作用
    
    # 关联关系
    effects = relationship(
        "EffectCategory",
        secondary=effect_ingredient_association,
        back_populates="ingredients"
    )
    products = relationship(
        "Product",
        secondary=ingredient_product_association,
        back_populates="ingredients"
    )

class Product(Base):
    """产品表"""
    __tablename__ = 'products'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(300), nullable=False)  # 产品名称
    brand = Column(String(100))  # 品牌
    category = Column(String(50))  # 产品类别（精华/面霜/洁面等）
    price = Column(Float)  # 价格
    volume = Column(String(50))  # 容量
    rating = Column(Float)  # 评分
    review_count = Column(Integer)  # 评价数量
    description = Column(Text)  # 产品描述
    full_ingredients = Column(Text)  # 完整成分表
    purchase_url = Column(String(500))  # 购买链接
    image_url = Column(String(500))  # 产品图片链接
    
    # 关联关系
    ingredients = relationship(
        "Ingredient",
        secondary=ingredient_product_association,
        back_populates="products"
    )
    suitable_skin_types = relationship(
        "SkinType",
        secondary=product_skintype_association,
        back_populates="suitable_products"
    )

class SkinType(Base):
    """肤质类型表"""
    __tablename__ = 'skin_types'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(50), nullable=False)  # 肤质名称
    description = Column(Text)  # 肤质描述
    characteristics = Column(Text)  # 肤质特征
    care_tips = Column(Text)  # 护理建议
    
    # 关联关系
    suitable_products = relationship(
        "Product",
        secondary=product_skintype_association,
        back_populates="suitable_skin_types"
    )

class IngredientInteraction(Base):
    """成分相互作用表"""
    __tablename__ = 'ingredient_interactions'
    
    id = Column(Integer, primary_key=True)
    ingredient1_id = Column(Integer, ForeignKey('ingredients.id'))
    ingredient2_id = Column(Integer, ForeignKey('ingredients.id'))
    interaction_type = Column(String(50))  # 协同/拮抗/禁忌
    description = Column(Text)  # 相互作用描述
    recommendation = Column(Text)  # 使用建议

