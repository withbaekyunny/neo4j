"""
化妆品成分筛选系统API路由
"""
from flask import Blueprint, jsonify, request
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine, desc, func
from src.models.cosmetic import (
    Base, EffectCategory, Ingredient, Product, SkinType, IngredientInteraction,
    effect_ingredient_association, ingredient_product_association, product_skintype_association
)

# 创建数据库连接
DATABASE_URL = "sqlite:///src/database/app.db"
engine = create_engine(DATABASE_URL)
Session = sessionmaker(bind=engine)

cosmetic_bp = Blueprint('cosmetic', __name__)

@cosmetic_bp.route('/api/effect-categories', methods=['GET'])
def get_effect_categories():
    """获取所有功效类别"""
    session = Session()
    try:
        categories = session.query(EffectCategory).all()
        result = []
        for category in categories:
            result.append({
                'id': category.id,
                'name': category.name,
                'description': category.description,
                'icon': category.icon
            })
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()

@cosmetic_bp.route('/api/ingredients/by-effect/<int:effect_id>', methods=['GET'])
def get_ingredients_by_effect(effect_id):
    """根据功效获取成分列表，按功效评分排序"""
    session = Session()
    try:
        # 查询与指定功效相关的成分
        ingredients = session.query(Ingredient).join(
            effect_ingredient_association,
            Ingredient.id == effect_ingredient_association.c.ingredient_id
        ).filter(
            effect_ingredient_association.c.effect_id == effect_id
        ).order_by(desc(Ingredient.efficacy_score)).all()
        
        result = []
        for ingredient in ingredients:
            result.append({
                'id': ingredient.id,
                'name': ingredient.name,
                'english_name': ingredient.english_name,
                'inci_name': ingredient.inci_name,
                'category': ingredient.category,
                'efficacy_score': ingredient.efficacy_score,
                'evidence_level': ingredient.evidence_level,
                'mechanism': ingredient.mechanism,
                'effective_concentration': ingredient.effective_concentration,
                'safety_level': ingredient.safety_level,
                'side_effects': ingredient.side_effects
            })
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()

@cosmetic_bp.route('/api/products/by-ingredient/<int:ingredient_id>', methods=['GET'])
def get_products_by_ingredient(ingredient_id):
    """根据成分获取产品列表，按成分在成分表中的位置排序"""
    session = Session()
    try:
        skin_type_id = request.args.get('skin_type_id', type=int)
        
        # 基础查询：获取包含指定成分的产品
        query = session.query(
            Product,
            ingredient_product_association.c.position_in_list
        ).join(
            ingredient_product_association,
            Product.id == ingredient_product_association.c.product_id
        ).filter(
            ingredient_product_association.c.ingredient_id == ingredient_id,
            ingredient_product_association.c.is_active == True
        )
        
        # 如果指定了肤质，进行二次筛选
        if skin_type_id:
            query = query.join(
                product_skintype_association,
                Product.id == product_skintype_association.c.product_id
            ).filter(
                product_skintype_association.c.skintype_id == skin_type_id
            )
        
        # 按成分在成分表中的位置排序（位置越靠前，含量越高）
        products_with_position = query.order_by(
            ingredient_product_association.c.position_in_list
        ).all()
        
        result = []
        for product, position in products_with_position:
            # 获取产品的所有关键成分
            key_ingredients = session.query(Ingredient).join(
                ingredient_product_association,
                Ingredient.id == ingredient_product_association.c.ingredient_id
            ).filter(
                ingredient_product_association.c.product_id == product.id,
                ingredient_product_association.c.is_active == True
            ).order_by(ingredient_product_association.c.position_in_list).all()
            
            # 获取适合的肤质
            suitable_skin_types = session.query(SkinType).join(
                product_skintype_association,
                SkinType.id == product_skintype_association.c.skintype_id
            ).filter(
                product_skintype_association.c.product_id == product.id
            ).all()
            
            result.append({
                'id': product.id,
                'name': product.name,
                'brand': product.brand,
                'category': product.category,
                'price': product.price,
                'volume': product.volume,
                'rating': product.rating,
                'review_count': product.review_count,
                'description': product.description,
                'full_ingredients': product.full_ingredients,
                'purchase_url': product.purchase_url,
                'image_url': product.image_url,
                'ingredient_position': position,
                'key_ingredients': [
                    {
                        'id': ing.id,
                        'name': ing.name,
                        'english_name': ing.english_name,
                        'category': ing.category,
                        'efficacy_score': ing.efficacy_score
                    } for ing in key_ingredients
                ],
                'suitable_skin_types': [
                    {
                        'id': st.id,
                        'name': st.name,
                        'description': st.description
                    } for st in suitable_skin_types
                ]
            })
        
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()

@cosmetic_bp.route('/api/skin-types', methods=['GET'])
def get_skin_types():
    """获取所有肤质类型"""
    session = Session()
    try:
        skin_types = session.query(SkinType).all()
        result = []
        for skin_type in skin_types:
            result.append({
                'id': skin_type.id,
                'name': skin_type.name,
                'description': skin_type.description,
                'characteristics': skin_type.characteristics,
                'care_tips': skin_type.care_tips
            })
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()

@cosmetic_bp.route('/api/stats/overview', methods=['GET'])
def get_overview_stats():
    """获取系统概览统计"""
    session = Session()
    try:
        effect_count = session.query(func.count(EffectCategory.id)).scalar()
        ingredient_count = session.query(func.count(Ingredient.id)).scalar()
        product_count = session.query(func.count(Product.id)).scalar()
        skin_type_count = session.query(func.count(SkinType.id)).scalar()
        
        result = {
            'total_effects': effect_count,
            'total_ingredients': ingredient_count,
            'total_products': product_count,
            'total_skin_types': skin_type_count
        }
        
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()

