
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './App.css';

const API_BASE_URL = 'http://localhost:5000/api'; // 后端API地址

// 首页 - 功效类别选择
const HomePage = () => {
  const [effectCategories, setEffectCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios.get(`${API_BASE_URL}/effect-categories`)
      .then(response => {
        setEffectCategories(response.data);
        setLoading(false);
      })
      .catch(error => {
        console.error('Error fetching effect categories:', error);
        setError('加载功效类别失败，请稍后再试。');
        setLoading(false);
      });
  }, []);

  if (loading) return <div className="flex justify-center items-center h-screen text-lg">加载中...</div>;
  if (error) return <div className="flex justify-center items-center h-screen text-red-500 text-lg">{error}</div>;

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-4xl font-bold text-center mb-8 text-gray-800">选择您关注的护肤功效</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {effectCategories.map(category => (
          <Link to={`/effects/${category.id}/ingredients`} key={category.id}>
            <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow duration-300 cursor-pointer flex flex-col items-center text-center">
              <span className="text-5xl mb-4" role="img" aria-label={category.name}>
                {category.icon === 'brightness' && '✨'}
                {category.icon === 'anti-aging' && '⏳'}
                {category.icon === 'droplet' && '💧'}
                {category.icon === 'shield' && '🛡️'}
                {category.icon === 'heart' && '❤️'}
                {category.icon === 'refresh' && '🔄'}
              </span>
              <h2 className="text-xl font-semibold text-gray-700 mb-2">{category.name}</h2>
              <p className="text-gray-600 text-sm">{category.description}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

// 成分列表页
const IngredientListPage = () => {
  const { effectId } = useParams();
  const [ingredients, setIngredients] = useState([]);
  const [effectName, setEffectName] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // 获取功效名称
    axios.get(`${API_BASE_URL}/effect-categories`)
      .then(response => {
        const category = response.data.find(cat => cat.id === parseInt(effectId));
        if (category) {
          setEffectName(category.name);
        }
      })
      .catch(error => console.error('Error fetching effect name:', error));

    // 获取成分列表
    axios.get(`${API_BASE_URL}/ingredients/by-effect/${effectId}`)
      .then(response => {
        setIngredients(response.data);
        setLoading(false);
      })
      .catch(error => {
        console.error('Error fetching ingredients:', error);
        setError('加载成分列表失败，请稍后再试。');
        setLoading(false);
      });
  }, [effectId]);

  if (loading) return <div className="flex justify-center items-center h-screen text-lg">加载中...</div>;
  if (error) return <div className="flex justify-center items-center h-screen text-red-500 text-lg">{error}</div>;

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold text-center mb-8 text-gray-800">{effectName} 相关成分</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {ingredients.map(ingredient => (
          <Link to={`/ingredients/${ingredient.id}/products`} key={ingredient.id}>
            <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow duration-300 cursor-pointer">
              <h2 className="text-xl font-semibold text-gray-700 mb-2">{ingredient.name} ({ingredient.english_name})</h2>
              <p className="text-gray-600 text-sm mb-1">分类: {ingredient.category}</p>
              <p className="text-gray-600 text-sm mb-1">功效评分: {ingredient.efficacy_score}</p>
              <p className="text-gray-600 text-sm">机制: {ingredient.mechanism.substring(0, 80)}...</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

// 产品列表页
const ProductListPage = () => {
  const { ingredientId } = useParams();
  const [products, setProducts] = useState([]);
  const [ingredientName, setIngredientName] = useState('');
  const [skinTypes, setSkinTypes] = useState([]);
  const [selectedSkinType, setSelectedSkinType] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // 获取成分名称
    axios.get(`${API_BASE_URL}/ingredients/${ingredientId}`)
      .then(response => {
        setIngredientName(response.data.name);
      })
      .catch(error => console.error('Error fetching ingredient name:', error));

    // 获取肤质类型
    axios.get(`${API_BASE_URL}/skin-types`)
      .then(response => {
        setSkinTypes(response.data);
      })
      .catch(error => console.error('Error fetching skin types:', error));

    // 获取产品列表
    fetchProducts(ingredientId, selectedSkinType);
  }, [ingredientId, selectedSkinType]);

  const fetchProducts = (ingId, skinTypeId) => {
    setLoading(true);
    setError(null);
    let url = `${API_BASE_URL}/products/by-ingredient/${ingId}`;
    if (skinTypeId) {
      url += `?skin_type_id=${skinTypeId}`;
    }
    axios.get(url)
      .then(response => {
        setProducts(response.data);
        setLoading(false);
      })
      .catch(error => {
        console.error('Error fetching products:', error);
        setError('加载产品列表失败，请稍后再试。');
        setLoading(false);
      });
  };

  const handleSkinTypeChange = (event) => {
    setSelectedSkinType(event.target.value);
  };

  if (loading) return <div className="flex justify-center items-center h-screen text-lg">加载中...</div>;
  if (error) return <div className="flex justify-center items-center h-screen text-red-500 text-lg">{error}</div>;

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold text-center mb-8 text-gray-800">含有 {ingredientName} 的产品</h1>
      <div className="mb-6 flex justify-center items-center">
        <label htmlFor="skin-type-select" className="mr-2 text-gray-700">根据肤质筛选:</label>
        <select
          id="skin-type-select"
          className="p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          value={selectedSkinType}
          onChange={handleSkinTypeChange}
        >
          <option value="">所有肤质</option>
          {skinTypes.map(st => (
            <option key={st.id} value={st.id}>{st.name}</option>
          ))}
        </select>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.length > 0 ? (
          products.map(product => (
            <Link to={`/products/${product.id}`} key={product.id}>
              <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow duration-300 cursor-pointer flex flex-col">
                <img src={product.image_url || 'https://via.placeholder.com/150'} alt={product.name} className="w-full h-48 object-contain mb-4 rounded-md" />
                <h2 className="text-xl font-semibold text-gray-700 mb-2">{product.brand} {product.name}</h2>
                <p className="text-gray-600 text-sm mb-1">价格: ¥{product.price}</p>
                <p className="text-gray-600 text-sm mb-1">评分: {product.rating} ({product.review_count} 评论)</p>
                <p className="text-gray-600 text-sm mb-1">主要成分: {product.key_ingredients.map(ing => ing.name).join(', ')}</p>
                <p className="text-gray-600 text-sm">适合肤质: {product.suitable_skin_types.map(st => st.name).join(', ')}</p>
              </div>
            </Link>
          ))
        ) : (
          <p className="col-span-full text-center text-gray-500 text-lg">没有找到相关产品。</p>
        )}
      </div>
    </div>
  );
};

// 产品详情页
const ProductDetailPage = () => {
  const { productId } = useParams();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios.get(`${API_BASE_URL}/products/${productId}`)
      .then(response => {
        setProduct(response.data);
        setLoading(false);
      })
      .catch(error => {
        console.error('Error fetching product details:', error);
        setError('加载产品详情失败，请稍后再试。');
        setLoading(false);
      });
  }, [productId]);

  if (loading) return <div className="flex justify-center items-center h-screen text-lg">加载中...</div>;
  if (error) return <div className="flex justify-center items-center h-screen text-red-500 text-lg">{error}</div>;
  if (!product) return <div className="flex justify-center items-center h-screen text-lg">产品未找到。</div>;

  return (
    <div className="container mx-auto p-4 bg-white rounded-lg shadow-md">
      <h1 className="text-3xl font-bold text-gray-800 mb-4">{product.brand} {product.name}</h1>
      <div className="flex flex-col md:flex-row gap-6">
        <div className="md:w-1/3">
          <img src={product.image_url || 'https://via.placeholder.com/300'} alt={product.name} className="w-full h-auto object-contain rounded-md shadow-sm" />
        </div>
        <div className="md:w-2/3">
          <p className="text-gray-700 text-lg mb-2"><strong>分类:</strong> {product.category}</p>
          <p className="text-gray-700 text-lg mb-2"><strong>价格:</strong> ¥{product.price}</p>
          <p className="text-gray-700 text-lg mb-2"><strong>容量:</strong> {product.volume}</p>
          <p className="text-gray-700 text-lg mb-2"><strong>评分:</strong> {product.rating} ({product.review_count} 评论)</p>
          <p className="text-gray-700 text-lg mb-4"><strong>描述:</strong> {product.description}</p>
          <h2 className="text-2xl font-semibold text-gray-800 mb-3">主要成分</h2>
          <ul className="list-disc list-inside mb-4">
            {product.ingredients.map(ing => (
              <li key={ing.id} className="text-gray-700 mb-1">
                <strong>{ing.name}</strong> ({ing.english_name}) - 分类: {ing.category}, 功效评分: {ing.efficacy_score}
                <p className="text-gray-600 text-sm ml-4">机制: {ing.mechanism}</p>
              </li>
            ))}
          </ul>
          <h2 className="text-2xl font-semibold text-gray-800 mb-3">适合肤质</h2>
          <ul className="list-disc list-inside mb-4">
            {product.suitable_skin_types.map(st => (
              <li key={st.id} className="text-gray-700 mb-1">
                <strong>{st.name}</strong>: {st.description}
              </li>
            ))}
          </ul>
          {product.purchase_url && (
            <a href={product.purchase_url} target="_blank" rel="noopener noreferrer" className="inline-block bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-700 transition-colors duration-300">
              前往购买
            </a>
          )}
        </div>
      </div>
    </div>
  );
};

const App = () => {
  return (
    <Router>
      <div className="min-h-screen bg-gray-100">
        <header className="bg-blue-700 text-white p-4 shadow-md">
          <nav className="container mx-auto flex justify-between items-center">
            <Link to="/" className="text-2xl font-bold">成分筛选宝典</Link>
            <div className="space-x-4">
              <Link to="/" className="hover:text-blue-200">首页</Link>
              {/* 可以添加更多导航链接 */}
            </div>
          </nav>
        </header>
        <main className="py-8">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/effects/:effectId/ingredients" element={<IngredientListPage />} />
            <Route path="/ingredients/:ingredientId/products" element={<ProductListPage />} />
            <Route path="/products/:productId" element={<ProductDetailPage />} />
          </Routes>
        </main>
        <footer className="bg-gray-800 text-white text-center p-4 mt-8">
          <p>&copy; 2025 成分筛选宝典. All rights reserved.</p>
        </footer>
      </div>
    </Router>
  );
};

export default App;


